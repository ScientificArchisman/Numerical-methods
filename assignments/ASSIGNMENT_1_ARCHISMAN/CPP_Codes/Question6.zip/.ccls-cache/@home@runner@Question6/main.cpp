#include <iostream>
#include <vector>

/**
 * Calculates the tensor product of two matrices.
 * 
 * @param matrix1 The first matrix, a 2D vector of integers or floats.
 * @param matrix2 The second matrix, a 2D vector of integers or floats.
 * @return The tensor product of the two matrices as a 2D vector.
 */
template<typename T>
std::vector<std::vector<T>> tensorProduct(const std::vector<std::vector<T>>& matrix1, const std::vector<std::vector<T>>& matrix2) {
    int m1_rows = matrix1.size();
    int m1_cols = matrix1[0].size();
    int m2_rows = matrix2.size();
    int m2_cols = matrix2[0].size();

    // Initialize the result matrix with zeros
    std::vector<std::vector<T>> result(m1_rows * m2_rows, std::vector<T>(m1_cols * m2_cols, 0));

    // Calculate the tensor product
    for (int i = 0; i < m1_rows; ++i) {
        for (int j = 0; j < m1_cols; ++j) {
            for (int k = 0; k < m2_rows; ++k) {
                for (int l = 0; l < m2_cols; ++l) {
                    result[i * m2_rows + k][j * m2_cols + l] = matrix1[i][j] * matrix2[k][l];
                }
            }
        }
    }

    return result;
}

/**
 * Prints a matrix to the standard output.
 * 
 * @param matrix The matrix to print, a 2D vector of integers or floats.
 */
template<typename T>
void printMatrix(const std::vector<std::vector<T>>& matrix) {
    for (const auto& row : matrix) {
        for (const auto& elem : row) {
            std::cout << elem << " ";
        }
        std::cout << std::endl;
    }
}

int main() {
    // Example matrices (Replace these with actual matrix data)
    std::vector<std::vector<int>> matrix1 = {{1, 2}, {3, 4}};
    std::vector<std::vector<int>> matrix2 = {{5, 6}, {7, 8}};

    auto result = tensorProduct(matrix1, matrix2);
    std::cout << "First Matrix: " << std::endl;
    printMatrix(matrix1);
  
  std::cout << "Second Matrix: " << std::endl;
  printMatrix(matrix2);
  
    std::cout << "Tensor product of matrix1 and matrix2 is: " << std::endl;
    printMatrix(result);

    return 0;
}
