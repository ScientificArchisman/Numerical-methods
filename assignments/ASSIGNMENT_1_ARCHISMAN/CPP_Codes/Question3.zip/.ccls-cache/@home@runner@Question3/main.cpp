#include <iostream>
#include <iostream>
#include <vector>
#include <cmath>

/**
 * Checks if a number is prime.
 * 
 * @param num The number to check for primality.
 * @return True if num is prime, False otherwise.
 */
bool isPrime(int num) {
    if (num < 2) return false; // 0 and 1 are not prime numbers.
    for (int divisor = 2; divisor * divisor <= num; ++divisor) {
        if (num % divisor == 0) return false;
    }
    return true;
}

/**
 * Generates a list of prime numbers within a specified range using the Sieve of Eratosthenes algorithm.
 * 
 * @param lowerLim The lower limit of the range.
 * @param upperLim The upper limit of the range.
 * @return A vector containing all prime numbers between lowerLim and upperLim, inclusive.
 */
std::vector<int> SieveOfEratosthenes(int lowerLim, int upperLim) {
    std::vector<bool> isPrime(upperLim + 1, true);
    isPrime[0] = isPrime[1] = false; // 0 and 1 are not primes.
    for (int num = 2; num * num <= upperLim; ++num) {
        if (isPrime[num]) {
            for (int multiple = num * num; multiple <= upperLim; multiple += num) {
                isPrime[multiple] = false;
            }
        }
    }
    std::vector<int> primes;
    for (int i = lowerLim; i <= upperLim; ++i) {
        if (isPrime[i]) primes.push_back(i);
    }
    return primes;
}

/**
 * Finds the factorial of a number using its prime factorization.
 * 
 * This function first finds all prime numbers up to 'num' using the Sieve of Eratosthenes.
 * It then calculates the factorial by multiplying the powers of these primes based on
 * how many times they divide 'num' and its predecessors.
 * 
 * @param num The number to find the factorial of.
 * @return The factorial of num as an int.
 */
int find_factorial_using_primes(int num) {
    std::vector<int> primes = SieveOfEratosthenes(2, num); // Find all primes up to num.
    long long factorial = 1; // Initialize the factorial result.
    for (int prime : primes) {
        long long count = 0;
        for (long long tempPrime = prime; tempPrime <= num; tempPrime *= prime) {
            count += num / tempPrime;
        }
        for (int i = 0; i < count; ++i) factorial *= prime;
    }
    return static_cast<int>(factorial);
}

int main() {
    // Test isPrime function
    int num = 5;
    std::cout << "Is " << num << " prime? " << std::boolalpha << isPrime(num) << std::endl;

    // Test SieveOfEratosthenes function
    int lowerLim = 30, upperLim = 100;
    std::vector<int> primes = SieveOfEratosthenes(lowerLim, upperLim);
    std::cout << "Primes between " << lowerLim << " and " << upperLim << " are: ";
    for (int prime : primes) std::cout << prime << " ";
    std::cout << std::endl;

    // Test find_factorial_using_primes function
    num = 10;
    int factorial = find_factorial_using_primes(num);
    std::cout << "Factorial of " << num << " using prime factorization is " << factorial << std::endl;

    return 0;
}
