#include <iostream>

/**
 * Calculates the factorial of a number using an iterative approach.
 * 
 * The factorial of a non-negative integer n is the product of all positive integers less than or equal to n.
 * It's denoted by n! and is defined as:
 * n! = n * (n-1) * (n-2) * ... * 2 * 1
 * Additionally, 0! is defined to be 1.
 * 
 * @param n The non-negative integer to calculate the factorial of.
 * @return The factorial of n as an integer.
 * 
 * Example:
 * int result = factorial_iterative(5);
 * std::cout << "Factorial of 5 is: " << result << std::endl; // Output: Factorial of 5 is: 120
 */
int factorial_iterative(int n) {
    int factorial = 1;
    for (int i = 1; i <= n; ++i) {
        factorial *= i;
    }
    return factorial;
}


/**
 * Calculates the factorial of a number recursively.
 * 
 * @param n The number to calculate the factorial of.
 * @return The factorial of n.
 */
int factorial_recursive(int n) {
    if (n == 0) return 1;
    else return n * factorial_recursive(n - 1);
}

/**
 * Calculates the number of ways to select r things from n things.
 * 
 * @param n The total number of things to select from.
 * @param r The number of things to select.
 * @return The number of ways to select r things from n things.
 * @throws std::invalid_argument If r is greater than n, or if r or n is negative.
 */
int nCr(int n, int r) {
    if (r > n) throw std::invalid_argument("r must be less than or equal to n");
    if (r < 0 || n < 0) throw std::invalid_argument("r and n must be positive");

    return factorial_recursive(n) / (factorial_recursive(r) * factorial_recursive(n - r));
}

int main() {
    int N = 10; // Number of things to select from
    int R = 5;  // Number of things to select
    // Test the functions
    std::cout << "Factorial of 10 with recursion is " << factorial_recursive(10) << std::endl;
    std::cout << "Factorial of 10 with iteration is " << factorial_iterative(10) << std::endl;
    try {
        std::cout << "Number of ways to select " << R << " things from " << N << " things is " << nCr(N, R) << std::endl;
    } catch (const std::invalid_argument& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
    return 0;
}