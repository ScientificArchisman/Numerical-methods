#include <iostream>
#include <vector>
#include <chrono> // For measuring execution time

// Function to perform bubble sort on a vector of integers or floating-point numbers
// Template allows the function to work with any type of elements that can be compared using '<' and '>'
template <typename T>
void bubbleSort(std::vector<T>& arr) {
    bool swapDone;
    int n = arr.size(); // Get the size of the array

    // Perform n-1 passes, or until no swaps are needed
    for (int passNum = n - 1; passNum > 0; passNum--) {
        // Initially, no swaps are done
        swapDone = false;

        // Traverse up to the last unsorted element
        for (int idx = 0; idx < passNum; idx++) {
            // If the current element is greater than the next, swap them
            if (arr[idx] > arr[idx + 1]) {
                std::swap(arr[idx], arr[idx + 1]); // Use std::swap for swapping
                swapDone = true; // Mark that a swap has occurred
            }
        }

        // If no swaps were done in this pass, the array is sorted
        if (!swapDone) {
            break; // Exit the loop early as the array is already sorted
        }
    }
}

// Function template to perform selection sort on a vector
// Works for any comparable types such as integers or floating-point numbers
template <typename T>
void selectionSort(std::vector<T>& arr) {
    int n = arr.size(); // Get the size of the vector
    int max_idx; // Variable to store the index of the maximum element

    // Move through the unsorted segments of the array
    for (int passNum = n - 1; passNum > 0; passNum--) {
        max_idx = 0; // Initialize the index of the maximum element to the first element

        // Find the index of the maximum element in the unsorted part of the vector
        for (int idx = 1; idx <= passNum; idx++) {
            if (arr[idx] > arr[max_idx]) {
                max_idx = idx;
            }
        }

        // Swap the maximum element with the last element in the unsorted part
        T temp = arr[passNum];
        arr[passNum] = arr[max_idx];
        arr[max_idx] = temp;
    }
}



// Function template for insertion sort on a vector of elements
// This works for any data type that can be compared using '<' (e.g., int, float)
template<typename T>
void insertionSort(std::vector<T>& arr) {
    int n = arr.size(); // Get the size of the vector

    // Iterate through the array starting from the second element
    for (int outer_idx = 1; outer_idx < n; outer_idx++) {
        T current = arr[outer_idx]; // Store the current element
        int inner_idx = outer_idx - 1;

        // Move elements of arr[0..i-1], that are greater than current,
        // to one position ahead of their current position
        while (inner_idx >= 0 && arr[inner_idx] > current) {
            arr[inner_idx + 1] = arr[inner_idx];
            inner_idx--;
        }

        // Insert the current element into its correct position
        arr[inner_idx + 1] = current;
    }
}


// Function to merge two sorted vectors into one sorted vector
template<typename T>
void joinTwoSortedArrays(const std::vector<T>& arr1, const std::vector<T>& arr2, std::vector<T>& finalArray) {
    int pointer1 = 0, pointer2 = 0, pointer3 = 0;
    while (pointer1 < arr1.size() && pointer2 < arr2.size()) {
        if (arr1[pointer1] < arr2[pointer2]) {
            finalArray[pointer3++] = arr1[pointer1++];
        } else {
            finalArray[pointer3++] = arr2[pointer2++];
        }
    }

    // Add the remaining elements of arr1
    while (pointer1 < arr1.size()) {
        finalArray[pointer3++] = arr1[pointer1++];
    }

    // Add the remaining elements of arr2
    while (pointer2 < arr2.size()) {
        finalArray[pointer3++] = arr2[pointer2++];
    }
}

// Merge sort function to sort a vector in place
template<typename T>
void mergeSort(std::vector<T>& arr) {
    if (arr.size() <= 1) return; // Base case

    int mid = arr.size() / 2;
    std::vector<T> left(arr.begin(), arr.begin() + mid);
    std::vector<T> right(arr.begin() + mid, arr.end());

    // Recursively sort the two halves
    mergeSort(left);
    mergeSort(right);

    // Merge the sorted halves
    joinTwoSortedArrays(left, right, arr);
}


// Function to print the first 10 elements of an array
template<typename T>
void printFirstTenElements(const std::vector<T>& arr) {
    for (int i = 0; i < 10 && i < arr.size(); i++) {
        std::cout << arr[i] << " ";
    }
    std::cout << "..."; // Indicate that the output is truncated
    std::cout << std::endl;
}


int main() {
    // Example large array
    std::vector<int> originalArray(10000); // Large array with 10,000 elements
    // Fill the array with random values
    for (int i = 0; i < originalArray.size(); i++) {
        originalArray[i] = rand() % 10000; // Random numbers between 0 and 9999
    }

    std::vector<int> arr; // Array to sort

    // Measure Bubble Sort
    arr = originalArray; // Reset array to original
    auto start = std::chrono::high_resolution_clock::now();
    bubbleSort(arr);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Bubble Sort took " << elapsed.count() << " seconds." << std::endl;

    // Measure Selection Sort
    arr = originalArray; // Reset array to original
    start = std::chrono::high_resolution_clock::now();
    selectionSort(arr);
    end = std::chrono::high_resolution_clock::now();
    elapsed = end - start;
    std::cout << "Selection Sort took " << elapsed.count() << " seconds." << std::endl;

    // Measure Insertion Sort
    arr = originalArray; // Reset array to original
    start = std::chrono::high_resolution_clock::now();
    insertionSort(arr);
    end = std::chrono::high_resolution_clock::now();
    elapsed = end - start;
    std::cout << "Insertion Sort took " << elapsed.count() << " seconds." << std::endl;

    // Measure Merge Sort
    arr = originalArray; // Reset array to original
    start = std::chrono::high_resolution_clock::now();
    mergeSort(arr);
    end = std::chrono::high_resolution_clock::now();
    elapsed = end - start;
    std::cout << "Merge Sort took " << elapsed.count() << " seconds." << std::endl;

    printFirstTenElements(arr);
    return 0;
}