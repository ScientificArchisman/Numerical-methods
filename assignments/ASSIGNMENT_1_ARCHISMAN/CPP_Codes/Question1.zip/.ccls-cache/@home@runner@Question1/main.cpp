#include <iostream>
#include <vector>
#include <cstdlib> // For srand() and rand()
#include <climits> // For INT_MIN and INT_MAX

// Function to generate a vector of random integers between min and max (inclusive)
std::vector<int> generateRandomIntegers(int count, int min, int max) {
    std::vector<int> randomNumbers(count);
    for (int &value : randomNumbers) {
        value = min + rand() % (max - min + 1);
    }
    return randomNumbers;
}

// Function to find the sum of elements in a vector
int findSum(const std::vector<int>& array) {
    int sum = 0;
    for (int value : array) {
        sum += value;
    }
    return sum;
}

// Function to find the minimum element in a vector
int findMin(const std::vector<int>& array) {
    int minimum = INT_MAX;
    for (int value : array) {
        if (value < minimum) {
            minimum = value;
        }
    }
    return minimum;
}

// Recursive function to find the minimum element in a vector
int findMinRecursive(const std::vector<int>& array, int index) {
    if (index == array.size() - 1) {
        return array[index];
    } else {
        int minOfRest = findMinRecursive(array, index + 1);
        return array[index] < minOfRest ? array[index] : minOfRest;
    }
}

// Function to find the maximum element in a vector
int findMax(const std::vector<int>& array) {
    int maximum = INT_MIN;
    for (int value : array) {
        if (value > maximum) {
            maximum = value;
        }
    }
    return maximum;
}

// Recursive function to find the maximum element in a vector
int findMaxRecursive(const std::vector<int>& array, int index) {
    if (index == array.size() - 1) {
        return array[index];
    } else {
        int maxOfRest = findMaxRecursive(array, index + 1);
        return array[index] > maxOfRest ? array[index] : maxOfRest;
    }
}

int main() {
    // Set the seed for reproducibility
    srand(1);

    // Generate 10 random integers between 0 and 100
    std::vector<int> randomNumbers = generateRandomIntegers(10, 0, 100);

    // Calculate sum, minimum, and maximum
    int sum = findSum(randomNumbers);
    int minimum = findMin(randomNumbers);
    int maximum = findMax(randomNumbers);
    int minimumRecursive = findMinRecursive(randomNumbers, 0);
    int maximumRecursive = findMaxRecursive(randomNumbers, 0);

    // Print results
    std::cout << "Random numbers are: ";
    for (int num : randomNumbers) {
        std::cout << num << " ";
    }
    std::cout << "\nSum of the random numbers is: " << sum;
    std::cout << "\nMinimum of the random numbers is: " << minimum;
    std::cout << "\nMinimum of the random numbers using recursion is: " << minimumRecursive;
    std::cout << "\nMaximum of the random numbers is: " << maximum;
    std::cout << "\nMaximum of the random numbers using recursion is: " << maximumRecursive << std::endl;

    return 0;
}
