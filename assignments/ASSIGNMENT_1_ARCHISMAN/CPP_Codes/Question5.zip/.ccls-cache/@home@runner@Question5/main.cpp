#include <vector>
#include <stdexcept>
#include <iostream>

/**
 * Multiplies two matrices.
 *
 * @param matrix1 The first matrix as a 2D vector.
 * @param matrix2 The second matrix as a 2D vector.
 * @return The product of the two matrices as a 2D vector.
 * @throws std::invalid_argument If the matrices cannot be multiplied due to incompatible dimensions.
 */
std::vector<std::vector<float>> matrix_multiply(const std::vector<std::vector<float>>& matrix1, const std::vector<std::vector<float>>& matrix2) {
    int m1_rows = matrix1.size();
    int m1_cols = matrix1[0].size();
    int m2_rows = matrix2.size();
    int m2_cols = matrix2[0].size();

    if (m1_cols != m2_rows) {
        throw std::invalid_argument("The number of columns in the first matrix must be equal to the number of rows in the second matrix.");
    }

    std::vector<std::vector<float>> product(m1_rows, std::vector<float>(m2_cols, 0));

    for (int i = 0; i < m1_rows; ++i) {
        for (int j = 0; j < m2_cols; ++j) {
            for (int k = 0; k < m1_cols; ++k) {
                product[i][j] += matrix1[i][k] * matrix2[k][j];
            }
        }
    }

    return product;
}


// I will be implementing 2 other algorithms - Divide and Conquer for matrix multiplication and Strassen's algorithm for matrix nultiplication whicg are better optimised for matrix multiplication (Divide and Conquer isn't better though but is fun to see in action!!). For this, I am defining some helper functions.


using Matrix = std::vector<std::vector<float>>;

// Adds two matrices
Matrix add(const Matrix& A, const Matrix& B) {
    int n = A.size();
    Matrix result(n, std::vector<float>(n, 0));
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            result[i][j] = A[i][j] + B[i][j];
    return result;
}

// Subtracts matrix B from matrix A
Matrix subtract(const Matrix& A, const Matrix& B) {
    int n = A.size();
    Matrix result(n, std::vector<float>(n, 0));
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            result[i][j] = A[i][j] - B[i][j];
    return result;
}


Matrix multiplyDivideAndConquer(const Matrix& A, const Matrix& B) {
    int n = A.size();
    Matrix result(n, std::vector<float>(n, 0));

    // Base case: if the matrix is 1x1
    if (n == 1) {
        result[0][0] = A[0][0] * B[0][0];
    } else {
        // Split matrices into quarters
        // Assuming n is even for simplicity
        int mid = n / 2;
        std::vector<Matrix> subA(4, Matrix(mid, std::vector<float>(mid)));
        std::vector<Matrix> subB(4, Matrix(mid, std::vector<float>(mid)));
        for (int i = 0; i < mid; ++i) {
            for (int j = 0; j < mid; ++j) {
                subA[0][i][j] = A[i][j];                     // A11
                subA[1][i][j] = A[i][j + mid];               // A12
                subA[2][i][j] = A[i + mid][j];               // A21
                subA[3][i][j] = A[i + mid][j + mid];         // A22

                subB[0][i][j] = B[i][j];                     // B11
                subB[1][i][j] = B[i][j + mid];               // B12
                subB[2][i][j] = B[i + mid][j];               // B21
                subB[3][i][j] = B[i + mid][j + mid];         // B22
            }
        }

        // Recursively multiply submatrices
        Matrix P1 = multiplyDivideAndConquer(subA[0], subB[0]);
        Matrix P2 = multiplyDivideAndConquer(subA[1], subB[2]);
        Matrix P3 = multiplyDivideAndConquer(subA[0], subB[1]);
        Matrix P4 = multiplyDivideAndConquer(subA[1], subB[3]);
        Matrix P5 = multiplyDivideAndConquer(subA[2], subB[0]);
        Matrix P6 = multiplyDivideAndConquer(subA[3], subB[2]);
        Matrix P7 = multiplyDivideAndConquer(subA[2], subB[1]);
        Matrix P8 = multiplyDivideAndConquer(subA[3], subB[3]);

        // Combine the results
        for (int i = 0; i < mid; ++i) {
            for (int j = 0; j < mid; ++j) {
                result[i][j] = P1[i][j] + P2[i][j]; // C11
                result[i][j + mid] = P3[i][j] + P4[i][j]; // C12
                result[i + mid][j] = P5[i][j] + P6[i][j]; // C21
                result[i + mid][j + mid] = P7[i][j] + P8[i][j]; // C22
            }
        }
    }
    return result;
}


/**
 * Performs matrix multiplication using Strassen's algorithm.
 * 
 * Strassen's algorithm improves upon the traditional approach to matrix multiplication
 * with a more efficient recursive strategy, reducing the complexity from O(n^3) to approximately O(n^2.81).
 * It's particularly effective for large matrices.
 * 
 * Note: This implementation assumes matrices are square and of size 2^n x 2^n.
 * 
 * @param A The first matrix as a 2D vector.
 * @param B The second matrix as a 2D vector.
 * @return The product of the two matrices as a 2D vector.
 */
Matrix strassenMultiply(const Matrix& A, const Matrix& B) {
    int n = A.size();

    // Base case: Use standard multiplication for 1x1 matrices
    if (n == 1) {
        return {{A[0][0] * B[0][0]}};
    }

    // Splitting matrices into quarters
    int newSize = n / 2;
    Matrix a11(newSize, std::vector<float>(newSize)),
           a12(newSize, std::vector<float>(newSize)),
           a21(newSize, std::vector<float>(newSize)),
           a22(newSize, std::vector<float>(newSize)),
           b11(newSize, std::vector<float>(newSize)),
           b12(newSize, std::vector<float>(newSize)),
           b21(newSize, std::vector<float>(newSize)),
           b22(newSize, std::vector<float>(newSize));

    // Filling in the submatrices
    for (int i = 0; i < newSize; i++) {
        for (int j = 0; j < newSize; j++) {
            a11[i][j] = A[i][j];
            a12[i][j] = A[i][j + newSize];
            a21[i][j] = A[i + newSize][j];
            a22[i][j] = A[i + newSize][j + newSize];
            b11[i][j] = B[i][j];
            b12[i][j] = B[i][j + newSize];
            b21[i][j] = B[i + newSize][j];
            b22[i][j] = B[i + newSize][j + newSize];
        }
    }

    // Applying the 7 Strassen's multiplication formulas
    auto P1 = strassenMultiply(add(a11, a22), add(b11, b22)); // P1 = (A11 + A22) * (B11 + B22)
    auto P2 = strassenMultiply(add(a21, a22), b11);           // P2 = (A21 + A22) * B11
    auto P3 = strassenMultiply(a11, subtract(b12, b22));      // P3 = A11 * (B12 - B22)
    auto P4 = strassenMultiply(a22, subtract(b21, b11));      // P4 = A22 * (B21 - B11)
    auto P5 = strassenMultiply(add(a11, a12), b22);           // P5 = (A11 + A12) * B22
    auto P6 = strassenMultiply(subtract(a21, a11), add(b11, b12)); // P6 = (A21 - A11) * (B11 + B12)
    auto P7 = strassenMultiply(subtract(a12, a22), add(b21, b22)); // P7 = (A12 - A22) * (B21 + B22)

    // Constructing the resulting matrix from the 4 submatrices
    Matrix c11 = add(subtract(add(P1, P4), P5), P7); // C11 = P1 + P4 - P5 + P7
    Matrix c12 = add(P3, P5);                        // C12 = P3 + P5
    Matrix c21 = add(P2, P4);                        // C21 = P2 + P4
    Matrix c22 = add(subtract(add(P1, P3), P2), P6); // C22 = P1 + P3 - P2 + P6

    // Combining the submatrices into a single result matrix
    Matrix result(n, std::vector<float>(n));
    for (int i = 0; i < newSize; i++) {
        for (int j = 0; j < newSize; j++) {
            result[i][j] = c11[i][j];
            result[i][j + newSize] = c12[i][j];
            result[i + newSize][j] = c21[i][j];
            result[i + newSize][j + newSize] = c22[i][j];
        }
    }
    return result;
}

// A function to print matrices neatly
void printMatrix(const Matrix& matrix, const std::string& label) {
    std::cout << label << ":\n";
    for (const auto& row : matrix) {
        for (auto val : row) std::cout << val << " ";
        std::cout << "\n";
    }
    std::cout << std::endl;
}


/**
 * Checks if a given matrix is symmetric.
 * 
 * A matrix is symmetric if it is square (equal number of rows and columns)
 * and if the element at (i, j) is equal to the element at (j, i) for all i, j.
 * 
 * @param matrix The matrix to check, represented as a 2D vector with elements of type int or float.
 * @return True if the matrix is symmetric, False otherwise.
 * @throws std::invalid_argument if the matrix is not square or is invalid.
 */
template<typename T>
bool isSymmetric(const std::vector<std::vector<T>>& matrix) {
    size_t numRows = matrix.size();

    // Check if the matrix is square
    for (const auto& row : matrix) {
        if (row.size() != numRows) {
            throw std::invalid_argument("Matrix must be square (equal number of rows and columns).");
        }
    }

    // Check for symmetry
    for (size_t i = 0; i < numRows; ++i) {
        for (size_t j = i + 1; j < numRows; ++j) { // Only need to check elements above the main diagonal
            if (matrix[i][j] != matrix[j][i]) {
                return false; // Found elements that do not satisfy the symmetry condition
            }
        }
    }

    return true; // If the loop completes without finding asymmetry, the matrix is symmetric
}


/**
 * Finds the transpose of a given matrix.
 * 
 * The transpose of a matrix is obtained by swapping its rows with its columns.
 * 
 * @param matrix The matrix to transpose, represented as a 2D vector with elements of type int or float.
 * @return The transpose of the input matrix as a 2D vector.
 */
template<typename T>
std::vector<std::vector<T>> transposeMatrix(const std::vector<std::vector<T>>& matrix) {
    if (matrix.empty()) return {}; // Return an empty matrix if the input is empty

    size_t numRows = matrix.size();
    size_t numCols = matrix[0].size();

    // Initialize the result matrix with the appropriate dimensions (numCols x numRows)
    std::vector<std::vector<T>> result(numCols, std::vector<T>(numRows));

    // Perform the transpose operation
    for (size_t i = 0; i < numRows; ++i) {
        for (size_t j = 0; j < numCols; ++j) {
            result[j][i] = matrix[i][j];
        }
    }

    return result;
}


/**
 * Prints a matrix to the standard output.
 * 
 * @param matrix The matrix to print, a 2D vector of integers or floats.
 */
template<typename T>
void printMatrix_simplified(const std::vector<std::vector<T>>& matrix) {
    for (const auto& row : matrix) {
        for (const auto& elem : row) {
            std::cout << elem << " ";
        }
        std::cout << std::endl;
    }
}





int main() {
    // Example 4x4 matrices
    Matrix A = {
        {1, 2, 3, 4},
        {5, 6, 7, 8},
        {9, 10, 11, 12},
        {13, 14, 15, 16}
    };
    Matrix B = {
        {16, 15, 14, 13},
        {12, 11, 10, 9},
        {8, 7, 6, 5},
        {4, 3, 2, 1}
    };
    // print the input
    printMatrix(A, "First Matrix");
    printMatrix(B, "Second Matrix");
  
    // Perform standard multiplication
    auto resultStandard = matrix_multiply(A, B);
    printMatrix(resultStandard, "Standard Multiplication Result");

    // Perform multiplication using the Divide and Conquer approach
    auto resultDC = multiplyDivideAndConquer(A, B);
    printMatrix(resultDC, "Divide and Conquer Multiplication Result");

    // Perform multiplication using Strassen's algorithm
    auto resultStrassen = strassenMultiply(A, B);
    printMatrix(resultStrassen, "Strassen's Multiplication Result");

    // Example matrices
    std::vector<std::vector<int>> symmetricMatrix = {
        {1, 2, 3},
        {2, 3, 4},
        {3, 4, 5}
    };

    std::vector<std::vector<int>> asymmetricMatrix = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    // Check if matrices are symmetric
    try {
        std::cout << "Checking symmetric matrix:" << std::endl;
        printMatrix_simplified(symmetricMatrix);
        std::cout << "Is symmetric? " << (isSymmetric(symmetricMatrix) ? "Yes" : "No") << std::endl;

        std::cout << "\nChecking asymmetric matrix:" << std::endl;
        printMatrix_simplified(asymmetricMatrix);
        std::cout << "Is symmetric? " << (isSymmetric(asymmetricMatrix) ? "Yes" : "No") << std::endl;
    } catch (const std::invalid_argument& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }


  // Example matrix
  std::vector<std::vector<int>> matrix = {
      {1, 2, 3},
      {4, 5, 6},
      {7, 8, 9}
  };

  std::cout << "Original matrix:" << std::endl;
  printMatrix_simplified(matrix);

  auto transposedMatrix = transposeMatrix(matrix);

  std::cout << "Transposed matrix:" << std::endl;
  printMatrix_simplified(transposedMatrix);
  
    return 0;
}
