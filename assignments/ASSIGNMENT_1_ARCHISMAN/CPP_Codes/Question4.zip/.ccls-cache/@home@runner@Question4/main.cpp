#include <iostream>
#include <cmath>
#include <stdexcept>

/**
 * Calculates factorial of a given number recursively.
 * 
 * @param n The number to calculate the factorial for.
 * @return The factorial of n as a long long.
 */
long long factorial_recursive(int n) {
    if (n == 0) return 1;
    else return n * factorial_recursive(n - 1);
}

/**
 * Calculates the cosine of x using the Taylor series expansion.
 * 
 * cos(x) = 1 - x^2/2! + x^4/4! - x^6/6! + ...
 * 
 * @param x The value to calculate cosine for.
 * @param n_terms The number of terms to use in the series expansion.
 * @return The cosine of x as a double.
 * @throws std::invalid_argument If n_terms is negative.
 */
double cos_series(double x, int n_terms = 100) {
    if (n_terms < 0) {
        throw std::invalid_argument("n_terms must be positive");
    }
    double cosx = 0;
    for (int k = 0; k < n_terms; ++k) {
        double term = std::pow(-1, k) * std::pow(x, 2 * k) / factorial_recursive(2 * k);
        cosx += term;
    }
    return cosx;
}


/**
 * Calculates the natural logarithm of (1+x) using a specific series expansion.
 * 
 * This function is designed to compute ln(1+x) based on the provided series expansion, which
 * optimizes computation by modifying the standard Taylor series approach.
 * 
 * @param x The input value for which to calculate ln(1+x), must be greater than -1.
 * @param n_terms The number of terms to use in the series for the approximation.
 * @return The calculated value of ln(1+x) as a double.
 * @throws std::invalid_argument If x is less than or equal to -1 or if n_terms is non-positive.
 */
double ln_1_plus_x_series(double x, int n_terms) {
    if (x <= -1) {
        throw std::invalid_argument("x must be greater than -1");
    }
    if (n_terms < 1) {
        throw std::invalid_argument("n_terms must be positive");
    }

    double lnx = 0;
    for (int k = 1; k <= n_terms; ++k) {
        // The formula as per the specific series 
        double power = 2 * k - 1;
        double term = 2 * std::pow(x / (x + 2), power) / power;
        lnx += term;
    }
    return lnx;
}

int main() {
    try {
        double x = 2; // Example value for x
        int n_terms = 10; // Number of terms to use in the series

        // Test the cos_series function
        std::cout << "cos(" << x << ") using " << n_terms << " terms is " << cos_series(x, n_terms) << std::endl;
        std::cout << "The true value of cos(" << x << ") is " << std::cos(x) << std::endl;

        // Test the ln_1_plus_x_series function
        std::cout << "ln(1 + " << x << ") using " << n_terms << " terms is " << ln_1_plus_x_series(x, n_terms) << std::endl;
        std::cout << "The true value of ln(1 + " << x << ") is " << std::log(1 + x) << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}